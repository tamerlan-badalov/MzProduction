var map = new OpenLayers.Map({
    div: "map",
    projection: new OpenLayers.Projection("EPSG:900913"),
    units: "m",
    restrictedExtent: new OpenLayers.Bounds(4400000, 4600000, 5700000, 5500000)
});
function init() {

    map.displayProjection = new OpenLayers.Projection("EPSG:4326");
    var gomapLayer = new OpenLayers.Layer.OSM(
        "GoMap.Az", "http://maps.gomap.az/info/xyz.do?lng=az&x=${x}&y=${y}&z=${z}&f=jpg", {
        "buffer": 0, attribution: "(c) <a href=“http://gomap.az/”>GoMap.Az</a>",
        tileOptions: { crossOriginKeyword: null },
        transitionEffect: "resize",
        zoomOffset: 7,
        numZoomLevels: 12,
        maxResolution: 1222.99245234375
    });
    map.addLayers([gomapLayer]);
    map.setCenter(new OpenLayers.LonLat(5551660.2717726, 4921653.5202719), 5);

}